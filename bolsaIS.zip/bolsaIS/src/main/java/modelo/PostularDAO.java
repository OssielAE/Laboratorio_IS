/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import org.hibernate.SessionFactory;

/**
 *
 * @author osq_c
 */
public class PostularDAO extends AbstractDAO{
    private SessionFactory sessionFactory;
    
    public PostularDAO() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }
    public void insert(Postular pos){
        this.insertDAO(pos);
    }
    public Postular select(int id){
        String consulta = "from Postular as p where p.idPostulacion = ";
        return (Postular)this.selectDAO(id, consulta);
    }
    public void update(Postular pos){
        this.updateDAO(pos);
    }
    public void delete(Postular pos){
        this.deleteDAO(pos);
    }
}
