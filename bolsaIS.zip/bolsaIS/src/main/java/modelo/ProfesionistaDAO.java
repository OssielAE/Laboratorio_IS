/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import org.hibernate.SessionFactory;

/**
 *
 * @author osq_c
 */
public class ProfesionistaDAO extends AbstractDAO{
    private SessionFactory sessionFactory;
    
    public ProfesionistaDAO() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }
    public void insert(Profesionista prof){
        this.insertDAO(prof);
    }
    public Profesionista select(String id){
        id = "'"+id+"'";
        String consulta = "from Profesionista as p where p.correo =";
        return (Profesionista)this.selectDAO(id, consulta);
    }
    public void update(Profesionista prof){
        this.updateDAO(prof);
    }
    public void delete(Profesionista prof){
        this.deleteDAO(prof);
    }
}
