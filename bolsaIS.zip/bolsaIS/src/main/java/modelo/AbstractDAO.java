/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author ossiel
 */
public class AbstractDAO {
    private SessionFactory sessionFactory;
    /**
     * Clase Abstracta padre parea las demas clases de tipo DAO
     */
    public AbstractDAO() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }
    /**
     * Inicializa la clase
     * @param Abs Objeto de la clase correspondiente al DAO
     */
    public void insertDAO(Object Abs) {
        Session session = sessionFactory.openSession();
        Transaction transaction = null;
        
        try {
           transaction = session.beginTransaction();
           session.persist(Abs);
           transaction.commit();
        }
        catch (Exception e) {
            
           if (transaction != null){ 
               transaction.rollback();
           }
           
           e.printStackTrace(); 
        }
        finally {
           session.close();
        }
    }
    /**
     * Regresa un objeto de la clase DAO correspondiente a la consulta pedida
     * @param id Identificador del Objeto buscado
     * @param consulta Consulta de Hibernate correspondiente
     * @return Resultado de la consulta
     */
    public Object selectDAO(Object id, String consulta) {
        Object resultado = null;
        Transaction transaccion = null;
        Session session = sessionFactory.openSession();
        
        try {
            transaccion = session.beginTransaction();
            String hql = consulta + (String)id;
            Query query = session.createQuery(hql);
            resultado = (Object)query.uniqueResult();
            transaccion.commit();
        }
        catch (Exception e) {

            if (transaccion!=null) {
                transaccion.rollback();
            }
            
            e.printStackTrace(); 
        }
        finally {
            session.close();
        }
        
        return resultado;
    }
    /**
     * Actualiza el Objeto al que se hace referencia
     * @param Abs Objeto que se va a actualizar
     */
    public void updateDAO(Object Abs) {
        Session session = sessionFactory.openSession();
        Transaction transaction = null;
        
        try {
           transaction = session.beginTransaction();
           session.update(Abs);
           transaction.commit();
        }
        catch (Exception e) {
            
           if (transaction != null){ 
               transaction.rollback();
           }
           
           e.printStackTrace(); 
        }
        finally {
           session.close();
        }
        
    }
    /**
     * Borra el objeto al que se hace referencia
     * @param Abs Objeto que se va a borrar
     */
    public void deleteDAO(Object Abs) {
        Session session = sessionFactory.openSession();
        Transaction transaction = null;
        
        try {
           transaction = session.beginTransaction();
           session.delete(Abs);
           transaction.commit();
        }
        catch (Exception e) {
            
           if (transaction != null){ 
               transaction.rollback();
           }
           
           e.printStackTrace(); 
        }
        finally {
           session.close();
        }
        
    }
    
}
