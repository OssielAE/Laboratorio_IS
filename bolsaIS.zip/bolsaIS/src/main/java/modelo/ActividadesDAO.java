/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import org.hibernate.SessionFactory;

/**
 *
 * @author Volkodlak
 */
public class ActividadesDAO extends AbstractDAO{
    private SessionFactory sessionFactory;
    
    public ActividadesDAO() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }
    public void insert(Actividades act){
        this.insertDAO(act);
    }
    public Actividades select(int id){
        String consulta = "from Actividades as ac where idActividad = ";
        return (Actividades)this.selectDAO(id, consulta);
    }
    public void update(Actividades act){
        this.updateDAO(act);
    }
    public void delete(Actividades act){
        this.deleteDAO(act);
    }
}