/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
 
import org.hibernate.SessionFactory;

/**
 *
 * @author osq_c
 */
public class EmpresaDAO extends AbstractDAO{
    private SessionFactory sessionFactory;
    
    public EmpresaDAO() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }
    public void insert(Empresa emp){
        this.insertDAO(emp);
    }
    public Empresa select(String id){
        String consulta = "from Empresa as e where e.nombreEmpresa = ";
        id = "'"+id+"'";
        return (Empresa)this.selectDAO(id, consulta);
    }
    public void update(Empresa emp){
        this.updateDAO(emp);
    }
    public void delete(Empresa emp){
        this.deleteDAO(emp);
    }
}
