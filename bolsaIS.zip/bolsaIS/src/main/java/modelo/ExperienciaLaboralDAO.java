/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import org.hibernate.SessionFactory;

/**
 *
 * @author osq_c
 */
public class ExperienciaLaboralDAO extends AbstractDAO{
        private SessionFactory sessionFactory;
    
    public ExperienciaLaboralDAO() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }
    public void insert(ExperienciaLaboral expl){
        this.insertDAO(expl);
    }
    public ExperienciaLaboral select(int id){
        String consulta = "from ExperienciaLaboral as e where idExperienciaLaboral =";
        return (ExperienciaLaboral)this.selectDAO(id, consulta);
    }
    public void update(ExperienciaLaboral expl){
        this.updateDAO(expl);
    }
    public void delete(ExperienciaLaboral expl){
        this.deleteDAO(expl);
    }
}
