/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author osq_c
 */
public class FormacionAcademicaDAO extends AbstractDAO{
    private SessionFactory sessionFactory;
    
    public FormacionAcademicaDAO() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }
    public void insert(FormacionAcademica form){
        this.insertDAO(form);
    }
    public FormacionAcademica select(int id){
        String consulta = "from FormacionAcademica as f where f.idFormacionAcademica =";
        return (FormacionAcademica)this.selectDAO(id, consulta);
    }
    public void update(FormacionAcademica form){
        this.updateDAO(form);
    }
    public void delete(FormacionAcademica form){
        this.deleteDAO(form);
    }
}
