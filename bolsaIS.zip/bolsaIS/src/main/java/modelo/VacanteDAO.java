/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import org.hibernate.SessionFactory;

/**
 *
 * @author osq_c
 */
public class VacanteDAO extends AbstractDAO{
    private SessionFactory sessionFactory;
    
    public VacanteDAO() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }
    public void insert(Vacante vac){
        this.insertDAO(vac);
    }
    public Vacante select(int id){
        String consulta = "from Vacante as e where e.idVacante = ";
        return (Vacante)this.selectDAO(id, consulta);
    }
    public void update(Vacante vac){
        this.updateDAO(vac);
    }
    public void delete(Vacante vac){
        this.deleteDAO(vac);
    }    
}
