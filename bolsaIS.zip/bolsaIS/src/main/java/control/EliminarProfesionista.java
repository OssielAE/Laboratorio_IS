package control;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import modelo.Profesionista;
import modelo.ProfesionistaDAO;

/**
 *
 * @author ossiel
 */
@ManagedBean
@ViewScoped
public class EliminarProfesionista {
    private String correo;

    public String getIdprofesionista() {
        return correo;
    }

    public void setIdprofesionista(String idprofesionista) {
        this.correo = idprofesionista;
    }
    
    public void eliminarProfesionista() {
        ProfesionistaDAO empDAO = new ProfesionistaDAO();
        Profesionista emp = empDAO.select(correo);
        empDAO.delete(emp);
    }
    
}
