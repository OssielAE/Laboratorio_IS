package control;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import modelo.FormacionAcademica;
import modelo.FormacionAcademicaDAO;
import modelo.Profesionista;
import modelo.ProfesionistaDAO;

/**
 *
 * @author ossiel
 */
@ManagedBean
@ViewScoped
public class ActualizarFormAcademica {
    private int idformacionac;
    private Profesionista profesionista;
    private String idProfesionista;
    private String grado;
    private String periodo;

    public int getIdformacionac() {
        return idformacionac;
    }
    public void setIdformacionac(int idformacionac) {
        this.idformacionac = idformacionac;
    }
    public Profesionista getProfesionista() {
        return profesionista;
    }
    public void setProfesionista(Profesionista profesionista) {
        this.profesionista = profesionista;
    }
    public String getIdProfesionista() {
        return idProfesionista;
    }
    public void setIdProfesionista(String idProfesionista) {
        this.idProfesionista = idProfesionista;
    }
    public String getNivel() {
        return grado;
    }
    public void setNivel(String nivel) {
        this.grado = nivel;
    }
    public String getPeriodo() {
        return periodo;
    }
    public void setPeriodo(String periodoc) {
        this.periodo = periodoc;
    }
    
    public void actualizarFormacionac() {
        FormacionAcademica frm = new FormacionAcademica();
        FormacionAcademicaDAO frmDAO = new FormacionAcademicaDAO();
	ProfesionistaDAO profDAO = new ProfesionistaDAO();
	profesionista = profDAO.select(idProfesionista);
        frm.setIdFormacionAcademica(idformacionac);
        frm.setProfesionista(profesionista);
        frm.setGrado(grado);
        frm.setPeriodo(periodo);
        frmDAO.update(frm);
    }
    
}
