package control;

import java.util.Set;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import modelo.ExperienciaLaboral;
import modelo.ExperienciaLaboralDAO;
import modelo.Profesionista;
import modelo.ProfesionistaDAO;

/**
 *
 * @author ossiel
 */
@ManagedBean
@ViewScoped
public class ActualizarExpLaboral {
    private int idexplaboral;
    private Profesionista profesionista;
    private String correo;
    private String empresa;
    private String cargo;
    private String periodo;

    public int getIdexplaboral() {
        return idexplaboral;
    }
    public void setIdexplaboral(int idexplaboral) {
        this.idexplaboral = idexplaboral;
    }
    public Profesionista getProfesionista() {
        return profesionista;
    }
    public void setProfesionista(Profesionista profesionista) {
        this.profesionista = profesionista;
    }
    public String getCorreoProf() {
        return correo;
    }
    public void setCorreoProf(String correo) {
        this.correo = correo;
    }
    public String getEmpresa() {
        return empresa;
    }
    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }
    public String getCargo() {
        return cargo;
    }
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    public String getPeriodo() {
        return periodo;
    }
    public void setPeriodoc(String periodo) {
        this.periodo = periodo;
    }
    
    public void actualizarExplaboral() {
        ExperienciaLaboral exp = new ExperienciaLaboral();
        ExperienciaLaboralDAO expDAO = new ExperienciaLaboralDAO();
	ProfesionistaDAO profDAO = new ProfesionistaDAO();
	profesionista = profDAO.select(correo);
        exp.setIdExperienciaLaboral(idexplaboral);
        exp.setProfesionista(profesionista);
        exp.setEmpresa(empresa);
        exp.setCargo(cargo);
        exp.setPeriodo(periodo);
        expDAO.update(exp);
    }
    
}
