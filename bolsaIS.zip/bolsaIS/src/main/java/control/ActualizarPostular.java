package control;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import modelo.Postular;
import modelo.PostularDAO;
import modelo.Profesionista;
import modelo.ProfesionistaDAO;
import modelo.Vacante;
import modelo.VacanteDAO;

/**
 *
 * @author ossiel
 */
@ManagedBean
@ViewScoped
public class ActualizarPostular {
    private int idpostular;
    private Profesionista profesionista;
    private String idProfesionista;
    private Vacante vacante;
    private int idVacante;

    public int getIdpostular() {
        return idpostular;
    }
    public void setIdpostular(int idpostular) {
        this.idpostular = idpostular;
    }
    public Profesionista getProfesionista() {
        return profesionista;
    }
    public void setProfesionista(Profesionista profesionista) {
        this.profesionista = profesionista;
    }
    public String getIdProfesionista() {
        return idProfesionista;
    }
    public void setIdProfesionista(String idProfesionista) {
        this.idProfesionista = idProfesionista;
    }
    public Vacante getVacante() {
        return vacante;
    }
    public void setVacante(Vacante vacante) {
        this.vacante = vacante;
    }
    public int getIdVacante() {
        return idVacante;
    }
    public void setIdVacante(int idVacante) {
        this.idVacante = idVacante;
    }

    public void actualizarPostular() {
        Postular pst = new Postular();
        PostularDAO pstDAO = new PostularDAO();
	ProfesionistaDAO profDAO = new ProfesionistaDAO();
        VacanteDAO vacDAO = new VacanteDAO();
	profesionista = profDAO.select(idProfesionista);
	vacante = vacDAO.select(idVacante);
        pst.setIdPostulacion(idpostular);
        pst.setProfesionista(profesionista);
        pst.setVacante(vacante);
        pstDAO.update(pst);
    }
}
