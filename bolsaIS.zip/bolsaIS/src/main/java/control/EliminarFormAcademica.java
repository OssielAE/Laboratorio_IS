package control;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import modelo.FormacionAcademica;
import modelo.FormacionAcademicaDAO;

/**
 *
 * @author ossiel
 */
@ManagedBean
@ViewScoped
public class EliminarFormAcademica {
    private int idformacionac;

    public int getIdformacionac() {
        return idformacionac;
    }

    public void setIdformacionac(int idformacionac) {
        this.idformacionac = idformacionac;
    }
    
    public void eliminarFormacionac() {
        FormacionAcademicaDAO empDAO = new FormacionAcademicaDAO();
        FormacionAcademica emp = empDAO.select(idformacionac);
        empDAO.delete(emp);
    }
}
