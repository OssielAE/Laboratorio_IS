package control;

import java.util.Set;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import modelo.Empresa;
import modelo.EmpresaDAO;
import modelo.Vacante;
import modelo.VacanteDAO;

/**
 *
 * @author ossiel
 */
@ManagedBean
@ViewScoped
public class ActualizarVacante {
    private int idvacante;
    private Empresa empresa;
    private String idEmpresa;
    private String lugar;
    private String horario;
    private String descripcion;
    private Set postulars;

    public int getIdvacante() {
        return idvacante;
    }
    public void setIdvacante(int idvacante) {
        this.idvacante = idvacante;
    }
    public Empresa getEmpresa() {
        return empresa;
    }
    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }
    public String getIdEmpresa() {
        return idEmpresa;
    }
    public void setIdEmpresa(String idEmpresa) {
        this.idEmpresa = idEmpresa;
    }
    public String getLugar() {
        return lugar;
    }
    public void setLugar(String lugar) {
        this.lugar = lugar;
    }
    public String getHorario() {
        return horario;
    }
    public void setHorario(String horario) {
        this.horario = horario;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public Set getPostulars() {
        return postulars;
    }
    public void setPostulars(Set postulars) {
        this.postulars = postulars;
    }
    
    public void actualizarVacante() {
        Vacante vac = new Vacante();
        VacanteDAO vacDAO = new VacanteDAO();
	EmpresaDAO empresaDAO = new EmpresaDAO();
        postulars = vacDAO.select(idvacante).getPostulars();
	empresa = empresaDAO.select(idEmpresa);
	vac.setIdVacante(idvacante);
	vac.setEmpresa(empresa);
	vac.setLugar(lugar);
	vac.setHorario(horario);
	vac.setDescripcion(descripcion);
	vac.setPostulars(postulars);
        vacDAO.update(vac);
    }
    
}
