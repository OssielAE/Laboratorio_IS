package control;

import java.util.Set;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import modelo.Profesionista;
import modelo.ProfesionistaDAO;

/**
 *
 * @author ossiel
 */
@ManagedBean
@ViewScoped
public class ActualizarProfesionista {
    private String correo;
    private String nombre;
    private String nacionalidad;
    private String carrera;
    private long telefono;
    private String contrasenia;
    private Set postulars;
    private Set habilidads;
    private Set formacionacs;
    private Set explaborals;

    public String getIdprofesionista() {
        return correo;
    }
    public void setIdprofesionista(String correo) {
        this.correo = correo;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNacionalidad() {
        return nacionalidad;
    }
    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }
    public String getCarrera() {
        return carrera;
    }
    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }
    public long getTelefono() {
        return telefono;
    }
    public void setTelefono(long telefono) {
        this.telefono = telefono;
    }
    public String getContrasenia() {
        return contrasenia;
    }
    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
    public Set getPostulars() {
        return postulars;
    }
    public void setPostulars(Set postulars) {
        this.postulars = postulars;
    }
    public Set getHabilidads() {
        return habilidads;
    }
    public void setHabilidads(Set habilidads) {
        this.habilidads = habilidads;
    }
    public Set getFormacionacs() {
        return formacionacs;
    }
    public void setFormacionacs(Set formacionacs) {
        this.formacionacs = formacionacs;
    }
    public Set getExplaborals() {
        return explaborals;
    }
    public void setExplaborals(Set explaborals) {
        this.explaborals = explaborals;
    }    
    public void actualizarProfesionista() {
        Profesionista prof = new Profesionista();
        ProfesionistaDAO profDAO = new ProfesionistaDAO();
	Profesionista profV = profDAO.select(correo);
        postulars = profV.getPostulars();
        formacionacs = profV.getFormacionAcademicas();
        explaborals = profV.getExperienciaLaborals();
        prof.setCarrera(correo);
        prof.setNombre(nombre);
        prof.setNacionalidad(nacionalidad);
        prof.setCarrera(carrera);
        prof.setTelefono(telefono);
        prof.setContrasenia(contrasenia);
        prof.setPostulars(postulars);
        prof.setFormacionAcademicas(formacionacs);
        prof.setExperienciaLaborals(explaborals);
        profDAO.update(prof);
    }
    
}
