package control;

import java.util.Set;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import modelo.Empresa;
import modelo.EmpresaDAO;

/**
 *
 * @author ossiel
 */
@ManagedBean
@ViewScoped
public class GuardarEmpresa {
    private String nombre;
    private String oficinas;
    private Integer numempleados;
    private String contacto;
    private Set vacantes;

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getOficinas() {
        return oficinas;
    }
    public void setOficinas(String oficinas) {
        this.oficinas = oficinas;
    }
    public Integer getNumempleados() {
        return numempleados;
    }
    public void setNumempleados(Integer numempleados) {
        this.numempleados = numempleados;
    }
    public String getContacto() {
        return contacto;
    }
    public void setContacto(String contacto) {
        this.contacto = contacto;
    }
    public Set getVacantes() {
        return vacantes;
    }
    public void setVacantes(Set vacantes) {
        this.vacantes = vacantes;
    }    
    public void guardarEmpresa() {
        Empresa emp = new Empresa();        
        emp.setNombreEmpresa(nombre);
        emp.setOficinas(oficinas);
        emp.setNumEmpleados(numempleados);
        emp.setContacto(contacto);
        EmpresaDAO empDAO = new EmpresaDAO();
        empDAO.insert(emp);
    }
    
}
