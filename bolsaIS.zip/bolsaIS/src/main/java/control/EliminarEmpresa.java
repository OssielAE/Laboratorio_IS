package control;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import modelo.Empresa;
import modelo.EmpresaDAO;

/**
 *
 * @author ossiel
 */
@ManagedBean
@ViewScoped
public class EliminarEmpresa {
    private String correo;

    public String getIdempresa() {
        return correo;
    }

    public void setIdempresa(String idempresa) {
        this.correo = idempresa;
    }
    
    public void eliminarEmpresa() {
        EmpresaDAO empDAO = new EmpresaDAO();
        Empresa emp = empDAO.select(correo);
        empDAO.delete(emp);
    }
}
