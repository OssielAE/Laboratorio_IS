package control;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import modelo.ExperienciaLaboral;
import modelo.ExperienciaLaboralDAO;

/**
 *
 * @author ossiel
 */
@ManagedBean
@ViewScoped
public class EliminarExpLaboral {
    private int idexplaboral;

    public int getIdexplaboral() {
        return idexplaboral;
    }

    public void setIdexplaboral(int idexplaboral) {
        this.idexplaboral = idexplaboral;
    }
    
    public void eliminarExplaboral() {
        ExperienciaLaboralDAO empDAO = new ExperienciaLaboralDAO();
        ExperienciaLaboral emp = empDAO.select(idexplaboral);
        empDAO.delete(emp);
    }
}
